-- Run in phpMyAdmin (database: stpaul) if you already imported the old database.sql
USE stpaul;
UPDATE gallery SET image='images/sports/championship.jpg' WHERE image='images/sports/football.jpg';
UPDATE gallery SET image='images/gallery/school lab.jpg'  WHERE image='images/events/science_fair.jpg';
UPDATE news    SET image='images/sports/championship.jpg' WHERE image='images/sports/football.jpg';
UPDATE news    SET image='images/gallery/school lab.jpg'  WHERE image='images/events/science_fair.jpg';
UPDATE team SET image='images/gallery/deputy.jpg'                       WHERE name LIKE 'Ruhweza%';
UPDATE team SET image='images/gallery/head of science department.jpg'  WHERE name LIKE 'Asiimwe%';
UPDATE team SET image='images/gallery/schl bursar.jpg'                  WHERE name LIKE '%Kihumuro%';
