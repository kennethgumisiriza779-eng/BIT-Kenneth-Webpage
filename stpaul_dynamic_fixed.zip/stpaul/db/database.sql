CREATE DATABASE IF NOT EXISTS stpaul CHARACTER SET utf8mb4;
USE stpaul;
CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, password_hash VARCHAR(255) NOT NULL);
CREATE TABLE categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL, slug VARCHAR(60) UNIQUE NOT NULL);
CREATE TABLE news (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(200) NOT NULL, category_id INT NULL, event_date DATE NOT NULL, excerpt TEXT, body TEXT, image VARCHAR(255) NOT NULL DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL);
CREATE TABLE gallery (id INT AUTO_INCREMENT PRIMARY KEY, caption VARCHAR(200) NOT NULL, category_id INT NULL, image VARCHAR(255) NOT NULL DEFAULT '',
  layout ENUM('normal','wide','tall') NOT NULL DEFAULT 'normal', sort_order INT NOT NULL DEFAULT 0, FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL);
CREATE TABLE team (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, role VARCHAR(120) NOT NULL, bio TEXT, image VARCHAR(255) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 0);
CREATE TABLE enquiries (id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(120) NOT NULL, email VARCHAR(150) NOT NULL, phone VARCHAR(40), subject VARCHAR(30) NOT NULL, message TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);

-- ===== seed data taken from the original static pages =====
INSERT INTO categories(name,slug) VALUES ('Academics','academics'),('Campus','campus'),('Sports','sports'),('Events','events'),('Students','students');
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('School Assembly — Students & Staff',(SELECT id FROM categories WHERE slug='students'),'images/gallery/assembly.jpg','wide',1);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Students on the Balcony',(SELECT id FROM categories WHERE slug='students'),'images/gallery/students_balcony.webp','tall',2);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('School Campus Buildings',(SELECT id FROM categories WHERE slug='campus'),'images/slider/slide2.jpg','normal',3);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Students in School Uniform',(SELECT id FROM categories WHERE slug='students'),'images/gallery/students_uniform.jpg','normal',4);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Students Group Gathering',(SELECT id FROM categories WHERE slug='students'),'images/gallery/group photo.jpg','normal',5);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Science Laboratory Block',(SELECT id FROM categories WHERE slug='campus'),'images/campus/lab1.jpg','normal',6);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Laboratory Corridor & Classrooms',(SELECT id FROM categories WHERE slug='campus'),'images/campus/lab2.jpg','wide',7);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Football Team — Champions',(SELECT id FROM categories WHERE slug='sports'),'images/sports/championship.jpg','normal',8);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Annual Science Exhibition',(SELECT id FROM categories WHERE slug='events'),'images/gallery/school lab.jpg','normal',9);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('Entrepreneurship Trade Show',(SELECT id FROM categories WHERE slug='events'),'images/gallery/trade_show.webp','normal',10);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('School Canteen',(SELECT id FROM categories WHERE slug='campus'),'images/gallery/school canteen.jpg','normal',11);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('School Grounds & Pathways',(SELECT id FROM categories WHERE slug='campus'),'images/campus/grounds.jpg','normal',12);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('New Dormitory Block',(SELECT id FROM categories WHERE slug='campus'),'images/campus/dorms.jpg','normal',13);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('School Signboard — Fort Portal City',(SELECT id FROM categories WHERE slug='campus'),'images/gallery/signpost board.jpg','normal',14);
INSERT INTO gallery(caption,category_id,image,layout,sort_order) VALUES ('St. Paul Schools Transport Van',(SELECT id FROM categories WHERE slug='campus'),'images/gallery/school van.jpg','normal',15);
INSERT INTO news(title,category_id,event_date,excerpt,body,image) VALUES ('Students Shine at Annual Science & Innovation Exhibition',(SELECT id FROM categories WHERE slug='academics'),'2026-04-25','St. Paul students presented impressive science and engineering projects, showcasing creativity and problem-solving skills to invited guests and judges.','St. Paul students presented impressive science and engineering projects, showcasing creativity and problem-solving skills to invited guests and judges.','images/gallery/school lab.jpg');
INSERT INTO news(title,category_id,event_date,excerpt,body,image) VALUES ('St. Paul Football Team Advances to Regional Championship',(SELECT id FROM categories WHERE slug='sports'),'2026-03-12','Our football team delivered outstanding performances, qualifying for the Fort Portal regional inter-school championship tournament.','Our football team delivered outstanding performances, qualifying for the Fort Portal regional inter-school championship tournament.','images/sports/championship.jpg');
INSERT INTO news(title,category_id,event_date,excerpt,body,image) VALUES ('New Academic Year 2026 Officially Begins with Grand Opening',(SELECT id FROM categories WHERE slug='events'),'2026-02-05','The 2026 academic year kicked off with a vibrant opening ceremony attended by parents, staff, and the district education officer.','The 2026 academic year kicked off with a vibrant opening ceremony attended by parents, staff, and the district education officer.','images/gallery/assembly.jpg');
INSERT INTO team(name,role,bio,image,sort_order) VALUES ('Busobozi Solomon','Headteacher','Experienced educational leader with a passion for academic excellence and student development.','images/team/headteacher.jpg',1);
INSERT INTO team(name,role,bio,image,sort_order) VALUES ('Ruhweza Abels','Deputy Headteacher (Academics)','Oversees the academic programs and coordinates the teaching staff across all levels.','images/gallery/deputy.jpg',2);
INSERT INTO team(name,role,bio,image,sort_order) VALUES ('Asiimwe whitney','Head of Sciences','Leads the science faculty, managing physics, chemistry, biology, and agriculture departments.','images/gallery/head of science department.jpg',3);
INSERT INTO team(name,role,bio,image,sort_order) VALUES ('MR.Kihumuro Isaac','School Bursar','Manages school finances, student accounts, and administrative services.','images/gallery/schl bursar.jpg',4);
