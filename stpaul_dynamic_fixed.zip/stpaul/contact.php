<?php require 'config.php';
check(); $sent=false; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $ajax=($_SERVER['HTTP_X_REQUESTED_WITH']??'')==='fetch';
  $n=trim($_POST['fullName']??''); $m=trim($_POST['email']??''); $p=trim($_POST['phone']??''); $s=$_POST['subject']??''; $t=trim($_POST['message']??'');
  if(($_POST['website']??'')!=='') $err='Spam detected.';
  elseif($n===''||!filter_var($m,FILTER_VALIDATE_EMAIL)||!in_array($s,['admissions','fees','academics','boarding','sports','other'],true)||mb_strlen($t)<5) $err='Please fill in all required fields correctly.';
  else { db()->prepare('INSERT INTO enquiries(full_name,email,phone,subject,message) VALUES(?,?,?,?,?)')->execute([$n,$m,$p,$s,$t]); $sent=true; }
  if($ajax){ header('Content-Type: application/json'); echo json_encode(['ok'=>$sent,'error'=>$err]); exit; }
}
$page='contact'; $title='Contact Us | St. Paul Senior Secondary School'; $desc='Contact St. Paul Senior Secondary School — Rwengoma, Fort Portal City. Reach us by phone, email, or visit us.';
$scripts='<script src="js/dynamic.js"></script>';
require 'includes/header.php'; ?>

<!-- PAGE HERO -->
<section class="page-hero">
  <div class="container page-hero-content">
    <h1>Contact Us</h1>
    <div class="breadcrumb">
      <a href="index.php">Home</a>
      <span>&#8250;</span>
      <span>Contact</span>
    </div>
  </div>
</section>

<!-- CONTACT SECTION -->
<section class="contact-section section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Get in Touch</span>
      <h2 class="section-title">We'd Love to <span>Hear From You</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Reach out to us for admissions inquiries, general information, or to schedule a school visit. Our team is ready to assist you.</p>
    </div>

    <div class="contact-grid">

      <!-- Contact Info Cards -->
      <div class="contact-info-cards">
        <div class="contact-info-card">
          <div class="ci-icon">&#128205;</div>
          <div class="ci-text">
            <h4>Physical Address</h4>
            <p>Rwengoma Hill, Bundibugyo Road<br/>Fort Portal City, Uganda</p>
          </div>
        </div>
        <div class="contact-info-card" style="transition-delay:0.1s;">
          <div class="ci-icon">&#128222;</div>
          <div class="ci-text">
            <h4>Phone Numbers</h4>
            <a href="tel:+256393100434">0393 100 434</a><br/>
            <a href="tel:+256788400935">0788 400 935</a><br/>
            <a href="tel:+256778949071">0778 949 071</a>
          </div>
        </div>
        <div class="contact-info-card" style="transition-delay:0.2s;">
          <div class="ci-icon">&#128231;</div>
          <div class="ci-text">
            <h4>Email Address</h4>
            <a href="mailto:stpaulsecondaryschool76@gmail.com">stpaulsecondaryschool76@gmail.com</a>
          </div>
        </div>
        <div class="contact-info-card" style="transition-delay:0.3s;">
          <div class="ci-icon">&#128241;</div>
          <div class="ci-text">
            <h4>WhatsApp</h4>
            <a href="https://wa.me/256788400935" target="_blank">+256 788 400 935</a>
            <p>Available Mon–Sat, 8am – 6pm</p>
          </div>
        </div>
        <div class="contact-info-card" style="transition-delay:0.4s;">
          <div class="ci-icon">&#128230;</div>
          <div class="ci-text">
            <h4>Postal Address</h4>
            <p>P.O. Box 289<br/>Fort Portal City, Uganda</p>
          </div>
        </div>
        <div class="contact-info-card" style="transition-delay:0.5s;">
          <div class="ci-icon">&#128336;</div>
          <div class="ci-text">
            <h4>School Hours</h4>
            <p>Monday – Friday: 7:30 AM – 5:00 PM<br/>Saturday: 8:00 AM – 1:00 PM</p>
          </div>
        </div>

        <!-- Social Media -->
        <div style="padding: 24px; background: var(--primary-xlight); border-radius: var(--radius); border: 1px solid var(--border);">
          <h4 style="font-size:0.9rem; font-weight:700; color:var(--text-dark); margin-bottom:16px;">Follow Us</h4>
          <div style="display:flex; gap:12px; flex-wrap:wrap;">
            <a href="#" style="display:inline-flex; align-items:center; gap:8px; padding:9px 18px; background:var(--primary); color:#fff; border-radius:50px; font-size:0.82rem; font-weight:600; transition:0.3s ease;">
              f Facebook
            </a>
            <a href="#" style="display:inline-flex; align-items:center; gap:8px; padding:9px 18px; background:#1DA1F2; color:#fff; border-radius:50px; font-size:0.82rem; font-weight:600; transition:0.3s ease;">
              t Twitter
            </a>
            <a href="https://wa.me/256788400935" target="_blank" style="display:inline-flex; align-items:center; gap:8px; padding:9px 18px; background:#25D366; color:#fff; border-radius:50px; font-size:0.82rem; font-weight:600; transition:0.3s ease;">
              W WhatsApp
            </a>
          </div>
        </div>
      </div>

      <!-- Contact Form -->
      <div class="contact-form-wrap">
        <h3>Send Us a Message</h3>
        <?php if($err) echo '<p class="error-msg" style="color:#C62828">'.e($err).'</p>'; ?>

        <!-- Form -->
        <form id="contactForm" method="post" action="contact.php" novalidate<?= $sent?' style="display:none"':'' ?>>
<?= csrf() ?><input type="text" name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">
          <div class="form-row">
            <div class="form-group">
              <label for="fullName">Full Name *</label>
              <input type="text" id="fullName" name="fullName" placeholder="Your full name" />
              <p class="error-msg" id="nameError" style="display:none; color:#C62828; font-size:0.8rem; margin-top:4px;">Please enter your full name.</p>
            </div>
            <div class="form-group">
              <label for="email">Email Address *</label>
              <input type="email" id="email" name="email" placeholder="your@email.com" />
              <p class="error-msg" id="emailError" style="display:none; color:#C62828; font-size:0.8rem; margin-top:4px;">Please enter a valid email address.</p>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input type="tel" id="phone" name="phone" placeholder="+256 700 000 000" />
            </div>
            <div class="form-group">
              <label for="subject">Subject *</label>
              <select id="subject" name="subject">
                <option value="">Select a subject...</option>
                <option value="admissions">Admissions Inquiry</option>
                <option value="fees">School Fees Information</option>
                <option value="academics">Academic Programs</option>
                <option value="boarding">Boarding Facilities</option>
                <option value="sports">Sports &amp; Activities</option>
                <option value="other">Other / General Inquiry</option>
              </select>
              <p class="error-msg" id="subjectError" style="display:none; color:#C62828; font-size:0.8rem; margin-top:4px;">Please select a subject.</p>
            </div>
          </div>
          <div class="form-group">
            <label for="message">Your Message *</label>
            <textarea id="message" name="message" placeholder="Write your message here..."></textarea>
            <p class="error-msg" id="messageError" style="display:none; color:#C62828; font-size:0.8rem; margin-top:4px;">Please enter your message.</p>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center; padding:14px;">
            &#9993; Send Message
          </button>
        </form>

        <!-- Success Message -->
        <div id="formSuccess" style="display:<?= $sent?'block':'none' ?>; text-align:center; padding:32px; background:#E8F5E9; border-radius:12px; color:#2E7D32;">
          <div style="font-size:3rem; margin-bottom:12px;">&#9989;</div>
          <h3>Message Sent Successfully!</h3>
          <p>Thank you for contacting St. Paul Senior Secondary School. We will get back to you within 24 hours.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- GOOGLE MAP -->
<section class="map-section">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Find Us</span>
      <h2 class="section-title">Our <span>Location</span></h2>
      <div class="divider"></div>
      <p class="section-desc">We are located at Rwengoma Hill, Bundibugyo Road, Fort Portal City, Uganda. Easy to find with clear signage.</p>
    </div>
    <div class="map-container">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.5!2d30.2833!3d0.6623!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMCzDsDM5JzQ0LjMiTiAzMMKwMTYnNTkuOSJF!5e0!3m2!1sen!2sug!4v1685000000000!5m2!1sen!2sug"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        title="St. Paul Senior Secondary School Location Map">
      </iframe>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <div class="cta-box">
      <h2>Ready to Enroll? Start the Admission Process Today</h2>
      <p>Don't miss the opportunity to give your child the best education in Fort Portal City. Spaces are limited. Apply now for S.1 and S.5.</p>
      <div class="cta-buttons">
        <a href="tel:+256393100434" class="btn btn-red">&#128222; Call Us Now</a>
        <a href="about.php" class="btn btn-outline">Learn About Us</a>
      </div>
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
