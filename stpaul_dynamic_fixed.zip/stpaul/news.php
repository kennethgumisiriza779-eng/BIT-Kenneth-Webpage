<?php require 'config.php'; $id=(int)($_GET['id']??0); $item=null;
if($id){ $s=db()->prepare('SELECT n.*,c.name AS cat FROM news n LEFT JOIN categories c ON c.id=n.category_id WHERE n.id=?'); $s->execute([$id]); $item=$s->fetch(); }
else $news=db()->query('SELECT n.*,c.name AS cat FROM news n LEFT JOIN categories c ON c.id=n.category_id ORDER BY n.event_date DESC')->fetchAll();
$page='news'; $title=($item?e($item['title']):'News &amp; Announcements').' | St. Paul Senior Secondary School';
$desc=$item?e($item['excerpt']):'Latest news and announcements from St. Paul Senior Secondary School.';
require 'includes/header.php'; ?>
<section class="page-hero"><div class="container page-hero-content"><h1><?= $item?e($item['title']):'News &amp; Announcements' ?></h1>
<div class="breadcrumb"><a href="index.php">Home</a><span>&#8250;</span><span>News</span></div></div></section>
<section class="news-section"><div class="container">
<?php if($id): if($item): ?>
<article><p class="news-date">&#128197; <?= date('F j, Y',strtotime($item['event_date'])) ?> &bull; <?= e($item['cat']) ?></p>
<?php if($item['image']): ?><img src="<?= e($item['image']) ?>" alt="<?= e($item['title']) ?>" class="news-img" /><?php endif; ?>
<p><?= nl2br(e($item['body'])) ?></p><p><a href="news.php" class="news-link">&#8592; All news</a></p></article>
<?php else: echo '<p>Article not found. <a href="news.php">All news</a></p>'; endif; else: ?>
<div class="news-grid"><?php foreach($news as $n) include 'includes/newscard.php'; ?></div>
<?php endif; ?></div></section>
<?php require 'includes/footer.php'; ?>
