<?php require 'config.php';
$page='services'; $title='Services &amp; Programs | St. Paul Senior Secondary School'; $desc='Academic programs and services offered at St. Paul Senior Secondary School — O-Level, A-Level Sciences, A-Level Arts, and more.';
require 'includes/header.php'; ?>

<!-- PAGE HERO -->
<section class="page-hero">
  <div class="container page-hero-content">
    <h1>Our Services &amp; Programs</h1>
    <div class="breadcrumb">
      <a href="index.php">Home</a>
      <span>&#8250;</span>
      <span>Services</span>
    </div>
  </div>
</section>

<!-- O-LEVEL SUBJECTS -->
<section class="subjects-section section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Ordinary Level</span>
      <h2 class="section-title">O-Level <span>Program (S.1 – S.4)</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Our Ordinary Level program offers a broad-based curriculum covering sciences, humanities, and practical subjects, aligned with the Uganda National Examinations Board (UNEB) requirements.</p>
    </div>
    <div class="subjects-grid">
      <div class="subject-card">
        <div class="subject-icon">&#128218;</div>
        <h4>English Language</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127981;</div>
        <h4>Mathematics</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128171;</div>
        <h4>Physics</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#9877;&#65039;</div>
        <h4>Chemistry</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127807;</div>
        <h4>Biology</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127758;</div>
        <h4>Geography</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128205;</div>
        <h4>History</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#9096;&#65039;</div>
        <h4>CRE / IRE</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128196;</div>
        <h4>Literature in English</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128187;</div>
        <h4>Computer Studies</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127807;</div>
        <h4>Agriculture</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128181;</div>
        <h4>Commerce</h4>
      </div>
    </div>
  </div>
</section>

<!-- A-LEVEL SCIENCES -->
<section class="subjects-section section-padding" style="background: var(--off-white);">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Advanced Level — Sciences</span>
      <h2 class="section-title">A-Level <span>Science Program (S.5 – S.6)</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Our science stream prepares students for degree programs in medicine, engineering, agriculture, and natural sciences at Uganda's top universities.</p>
    </div>
    <div class="subjects-grid">
      <div class="subject-card">
        <div class="subject-icon">&#128171;</div>
        <h4>Physics</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#9877;&#65039;</div>
        <h4>Chemistry</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127807;</div>
        <h4>Biology</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127981;</div>
        <h4>Mathematics</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127807;</div>
        <h4>Agriculture</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127859;</div>
        <h4>Foods &amp; Nutrition</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128221;</div>
        <h4>Technical Drawing</h4>
      </div>
    </div>
  </div>
</section>

<!-- A-LEVEL ARTS -->
<section class="subjects-section section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Advanced Level — Arts &amp; Humanities</span>
      <h2 class="section-title">A-Level <span>Arts Program (S.5 – S.6)</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Our arts and humanities stream opens doors to law, education, social sciences, business, and public administration careers.</p>
    </div>
    <div class="subjects-grid">
      <div class="subject-card">
        <div class="subject-icon">&#128205;</div>
        <h4>History</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128176;</div>
        <h4>Economics</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#127758;</div>
        <h4>Geography</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#9096;&#65039;</div>
        <h4>CRE</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#9096;&#65039;</div>
        <h4>IRE</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128218;</div>
        <h4>Literature in English</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128181;</div>
        <h4>Entrepreneurship</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128172;</div>
        <h4>Kiswahili</h4>
      </div>
      <div class="subject-card">
        <div class="subject-icon">&#128172;</div>
        <h4>Rutooro</h4>
      </div>
    </div>
  </div>
</section>

<!-- SUBSIDIARIES -->
<section class="subsidiaries-section">
  <div class="container">
    <div class="section-header" style="margin-bottom:40px;">
      <span class="section-tag" style="background:rgba(255,255,255,0.2); color:#fff;">Subsidiary Subjects</span>
      <h2 class="section-title" style="color:#fff;">Subsidiary <span style="color:rgba(255,255,255,0.75)">Programs</span></h2>
      <div class="divider"></div>
      <p class="section-desc" style="color:rgba(255,255,255,0.8);">All A-Level students take subsidiary subjects to broaden their academic competency.</p>
    </div>
    <div class="subsidiaries-grid">
      <div class="subsidiary-card">
        <div class="subject-icon" style="font-size:2.2rem; margin-bottom:12px;">&#128196;</div>
        <h4>General Paper</h4>
      </div>
      <div class="subsidiary-card">
        <div class="subject-icon" style="font-size:2.2rem; margin-bottom:12px;">&#128187;</div>
        <h4>Subsidiary ICT</h4>
      </div>
      <div class="subsidiary-card">
        <div class="subject-icon" style="font-size:2.2rem; margin-bottom:12px;">&#127981;</div>
        <h4>Subsidiary Mathematics</h4>
      </div>
    </div>
  </div>
</section>

<!-- ADDITIONAL SERVICES -->
<section class="subjects-section section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Facilities &amp; Support Services</span>
      <h2 class="section-title">Beyond the <span>Classroom</span></h2>
      <div class="divider"></div>
      <p class="section-desc">We provide a comprehensive range of support services and facilities to ensure the holistic development of every student.</p>
    </div>
    <div class="services-extra-grid">
      <div class="service-extra-card">
        <img src="images/campus/lab1.jpg" alt="ICT Laboratory" class="service-extra-img" />
        <div class="service-extra-body">
          <div class="service-extra-icon">&#128187;</div>
          <h3>ICT Laboratory</h3>
          <p>Our computer laboratory is equipped with modern computers and internet connectivity, giving students hands-on ICT skills aligned with the digital economy.</p>
        </div>
      </div>
      <div class="service-extra-card">
        <img src="images/gallery/school lab.jpg" alt="Science Laboratory" class="service-extra-img" />
        <div class="service-extra-body">
          <div class="service-extra-icon">&#9877;&#65039;</div>
          <h3>Science Laboratories</h3>
          <p>Fully equipped physics, chemistry, and biology laboratories where students conduct hands-on experiments under the guidance of qualified science teachers.</p>
        </div>
      </div>
      <div class="service-extra-card">
        <img src="images/campus/building1.jpg" alt="Library" class="service-extra-img" />
        <div class="service-extra-body">
          <div class="service-extra-icon">&#128218;</div>
          <h3>School Library</h3>
          <p>A well-stocked library with textbooks, reference books and quiet study space for students and staff.</p>
        </div>
      </div>
      <div class="service-extra-card">
        <img src="images/gallery/championship.jpg" alt="Sports Grounds" class="service-extra-img" />
        <div class="service-extra-body">
          <div class="service-extra-icon">&#9917;</div>
          <h3>Sports Programs</h3>
          <p>Active sports programs including football, netball, volleyball, and athletics. We participate in inter-school competitions and district championships.</p>
        </div>
      </div>
      <div class="service-extra-card">
        <img src="images/campus/dorms.jpg" alt="Boarding Section" class="service-extra-img" />
        <div class="service-extra-body">
          <div class="service-extra-icon">&#127968;</div>
          <h3>Boarding Section</h3>
          <p>Safe and comfortable boarding facilities for both boys and girls, with dedicated house parents providing supervision, meals, and pastoral care.</p>
        </div>
      </div>
      <div class="service-extra-card">
        <img src="images/gallery/group photo.jpg" alt="Guidance and Counseling" class="service-extra-img" />
        <div class="service-extra-body">
          <div class="service-extra-icon">&#129309;</div>
          <h3>Guidance &amp; Counseling</h3>
          <p>Qualified counselors provide academic guidance, career counseling, and emotional support to help students navigate challenges and achieve their goals.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <div class="cta-box">
      <h2>Start Your Academic Journey at St. Paul</h2>
      <p>Enroll your child in a school that truly invests in their future. Admissions for S.1 and S.5 are open. Contact us today for guidance.</p>
      <div class="cta-buttons">
        <a href="contact.php" class="btn btn-red">Apply Now &#8594;</a>
        <a href="portfolio.php" class="btn btn-outline">Our Achievements</a>
      </div>
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
