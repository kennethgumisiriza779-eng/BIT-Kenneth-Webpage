<?php require_once __DIR__.'/../config.php';
$nav=['index'=>'Home','about'=>'About','services'=>'Services','portfolio'=>'Portfolio','gallery'=>'Gallery','contact'=>'Contact Us']; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="<?= $desc ?>" />
  <title><?= $title ?></title>
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="icon" type="image/png" href="images/logo/st pauls dadge.png" />
</head>
<body>
<div class="preloader" id="preloader">
  <img src="images/logo/st pauls dadge.png" alt="St. Paul Logo" />
  <div class="preloader-bar"><div class="preloader-fill"></div></div>
</div>
<nav class="navbar" id="navbar">
  <div class="nav-container">
    <a href="index.php" class="nav-logo">
      <img src="images/logo/st pauls dadge.png" alt="St. Paul Logo" />
      <div class="nav-logo-text">
        <span class="nav-logo-name">St. Paul Senior Secondary School</span>
        <span class="nav-logo-motto">"We Invest for a Better Future"</span>
      </div>
    </a>
    <ul class="nav-links" id="navLinks">
      <?php foreach($nav as $k=>$l): $c=trim(($k==='contact'?'nav-cta ':'').($page===$k?'active':'')); ?>
      <li><a href="<?= $k ?>.php"<?= $c?' class="'.$c.'"':'' ?>><?= $l ?></a></li>
      <?php endforeach; ?>
    </ul>
    <button class="nav-toggle" id="navToggle" aria-label="Toggle menu"><span></span><span></span><span></span></button>
  </div>
</nav>
