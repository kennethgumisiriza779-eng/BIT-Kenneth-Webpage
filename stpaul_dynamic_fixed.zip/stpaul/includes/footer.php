<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="images/logo/st pauls dadge.png" alt="St. Paul Logo" />
        <h3>St. Paul Senior Secondary School</h3>
        <p class="footer-motto">"We Invest for a Better Future"</p>
        <p>A leading academic institution at Rwengoma Hill, Fort Portal City, committed to holistic student development and educational excellence.</p>
        <div class="social-links">
          <a href="#" class="social-link" title="Facebook">f</a>
          <a href="#" class="social-link" title="Twitter">t</a>
          <a href="#" class="social-link" title="WhatsApp">W</a>
          <a href="#" class="social-link" title="YouTube">Y</a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul class="footer-links">
          <li><a href="index.php">&#8594; Home</a></li>
          <li><a href="about.php">&#8594; About Us</a></li>
          <li><a href="services.php">&#8594; Services</a></li>
          <li><a href="portfolio.php">&#8594; Portfolio</a></li>
          <li><a href="gallery.php">&#8594; Gallery</a></li>
          <li><a href="news.php">&#8594; News</a></li>
          <li><a href="contact.php">&#8594; Contact</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Programs</h4>
        <ul class="footer-links">
          <li><a href="services.php">&#8594; O-Level Program</a></li>
          <li><a href="services.php">&#8594; A-Level Sciences</a></li>
          <li><a href="services.php">&#8594; A-Level Arts</a></li>
          <li><a href="services.php">&#8594; ICT &amp; Laboratory</a></li>
          <li><a href="services.php">&#8594; Sports &amp; Culture</a></li>
          <li><a href="services.php">&#8594; Boarding Section</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact Info</h4>
        <div class="footer-contact-items">
          <div class="footer-contact-item">
            <span>&#128205;</span>
            <span>Rwengoma Hill, Bundibugyo Road, Fort Portal City, Uganda</span>
          </div>
          <div class="footer-contact-item">
            <span>&#128222;</span>
            <span>0393 100 434 / 0788 400 935</span>
          </div>
          <div class="footer-contact-item">
            <span>&#128231;</span>
            <span>stpaulsecondaryschool76@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <span>&#128230;</span>
            <span>P.O. Box 289, Fort Portal City</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container" style="display:flex; justify-content:space-between; width:100%; align-items:center; flex-wrap:wrap; gap:8px;">
      <span>&copy; <?= date('Y') ?> St. Paul Secondary School. All Rights Reserved.</span>
      <span>Developed By <strong style="color:rgba(255,255,255,0.75)">Gumisiriza Kenneth</strong></span>
    </div>
  </div>
</footer>

<button class="back-to-top" id="backToTop" aria-label="Back to top">&#8679;</button>
<script src="js/script.js"></script>
<?= $scripts ?? '' ?>
</body>
</html>
