<?php require 'config.php';
$news=db()->query('SELECT n.*,c.name AS cat FROM news n LEFT JOIN categories c ON c.id=n.category_id ORDER BY n.event_date DESC LIMIT 3')->fetchAll();
$page='index'; $title='St. Paul Senior Secondary School | Home'; $desc='St. Paul Senior Secondary School — Rwengoma, Fort Portal City. We Invest for a Better Future.';
require 'includes/header.php'; ?>

<section class="hero-section">
  <div class="slider-wrapper">

    <div class="slide active">
      <div class="slide-bg" style="background-image: url('images/gallery/assembly.jpg');"></div>
      <div class="slide-overlay"></div>
      <div class="slide-content container">
        <div class="slide-text">
          <span class="slide-tag">&#127891; Welcome to St. Paul</span>
          <h1 class="slide-title">Shaping Leaders of<br />Tomorrow, Today</h1>
          <p class="slide-subtitle">Located at Rwengoma Hill, Fort Portal City — a center of academic excellence, discipline, and holistic development since 2005.</p>
          <div class="slide-actions">
            <a href="about.php" class="btn btn-primary">&#8594; Discover More</a>
            <a href="contact.php" class="btn btn-outline">Apply Now</a>
          </div>
        </div>
      </div>
    </div>

    <div class="slide">
      <div class="slide-bg" style="background-image: url('images/gallery/students_balcony.webp');"></div>
      <div class="slide-overlay"></div>
      <div class="slide-content container">
        <div class="slide-text">
          <span class="slide-tag">&#127979; Academic Excellence</span>
          <h1 class="slide-title">Quality Education for<br />Every Learner</h1>
          <p class="slide-subtitle">Offering both O-Level and A-Level programs with dedicated teachers committed to your child's success and future.</p>
          <div class="slide-actions">
            <a href="services.php" class="btn btn-primary">&#8594; Our Programs</a>
            <a href="gallery.php" class="btn btn-outline">View Gallery</a>
          </div>
        </div>
      </div>
    </div>

    <div class="slide">
      <div class="slide-bg" style="background-image: url('images/campus/lab1.jpg');"></div>
      <div class="slide-overlay"></div>
      <div class="slide-content container">
        <div class="slide-text">
          <span class="slide-tag">&#127942; Our Facilities</span>
          <h1 class="slide-title">Modern Facilities to<br />Inspire Learning</h1>
          <p class="slide-subtitle">From well-equipped science laboratories to spacious classrooms and boarding facilities — we provide the best environment for learning.</p>
          <div class="slide-actions">
            <a href="portfolio.php" class="btn btn-primary">&#8594; Our Achievements</a>
            <a href="contact.php" class="btn btn-outline">Get in Touch</a>
          </div>
        </div>
      </div>
    </div>

    <button class="slider-arrow slider-prev" id="sliderPrev" aria-label="Previous slide">&#8592;</button>
    <button class="slider-arrow slider-next" id="sliderNext" aria-label="Next slide">&#8594;</button>

    <div class="slider-dots">
      <div class="slider-dot active"></div>
      <div class="slider-dot"></div>
      <div class="slider-dot"></div>
    </div>

    <div class="scroll-indicator">
      <div class="scroll-line"></div>
      <span>Scroll</span>
    </div>
  </div>
</section>
<section class="intro-section">
  <div class="container">
    <div class="intro-grid">
      <div class="intro-image-wrap">
        <img src="images/slider/slide2.jpg" alt="St. Paul School Buildings" />
        <div class="intro-badge">
          <span class="intro-badge-num">20+</span>
          <span class="intro-badge-label">Years of Excellence</span>
        </div>
      </div>
      <div class="intro-content">
        <span class="section-tag">About St. Paul</span>
        <h2 class="section-title">A Legacy of <span>Academic Excellence</span> in Fort Portal</h2>
        <p>St. Paul Senior Secondary School is a distinguished educational institution located at Rwengoma Hill, Bundibugyo Road, Fort Portal City, Uganda. We offer both Ordinary Level (O-Level) and Advanced Level (A-Level) programs, grounded in discipline, academic rigor, and spiritual growth.</p>
        <p>Our motto — <em>"We Invest for a Better Future"</em> — drives everything we do. We believe every student deserves quality education, strong mentorship, and the opportunity to excel in a rapidly changing world.</p>
        <div class="intro-features">
          <div class="intro-feature">
            <div class="intro-feature-icon">&#127979;</div>
            <span>O-Level and A-Level Programs (Sciences &amp; Arts)</span>
          </div>
          <div class="intro-feature">
            <div class="intro-feature-icon">&#127962;</div>
            <span>Modern Science Laboratories &amp; ICT Lab</span>
          </div>
          <div class="intro-feature">
            <div class="intro-feature-icon">&#127968;</div>
            <span>Boarding Facilities for Students</span>
          </div>
          <div class="intro-feature">
            <div class="intro-feature-icon">&#127942;</div>
            <span>Active Sports, Culture &amp; Co-curricular Programs</span>
          </div>
        </div>
        <a href="about.php" class="btn btn-primary">Learn More About Us &#8594;</a>
      </div>
    </div>
  </div>
</section>

<section class="highlights-section">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">What We Offer</span>
      <h2 class="section-title">Built on Three <span>Pillars of Excellence</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Everything we do is designed to give our students the best foundation for life, career, and community.</p>
    </div>
    <div class="highlights-grid">
      <div class="highlight-card">
        <div class="highlight-icon">&#127979;</div>
        <h3>Academic Excellence</h3>
        <p>Qualified and dedicated teachers delivering quality O-Level and A-Level education. We maintain high academic standards with consistent pass rates and university placements.</p>
      </div>
      <div class="highlight-card">
        <div class="highlight-icon">&#127963;</div>
        <h3>Modern Facilities</h3>
        <p>Well-equipped science laboratories, ICT lab, library, spacious classrooms, and boarding facilities. We continually invest in infrastructure to support learning.</p>
      </div>
      <div class="highlight-card">
        <div class="highlight-icon">&#9989;</div>
        <h3>Discipline &amp; Values</h3>
        <p>A structured, supportive environment that builds character, integrity, and moral values in every student. We produce well-rounded graduates ready for life.</p>
      </div>
    </div>
  </div>
</section>

<section class="stats-section">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item">
        <span class="stat-number">478+</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Current Students</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">5,897+</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Alumni Worldwide</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">64</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Dedicated Staff</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">20+</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Years of Excellence</span>
      </div>
    </div>
  </div>
</section>

<section class="news-section">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Latest Updates</span>
      <h2 class="section-title">News &amp; <span>Highlights</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Stay informed about the latest events, achievements, and announcements from St. Paul Senior Secondary School.</p>
    </div>
    <div class="news-grid">
<?php foreach($news as $n) include 'includes/newscard.php'; ?>
</div>
  </div>
</section>

<!-- CTA SECTION -->
<section class="cta-section">
  <div class="container">
    <div class="cta-box">
      <h2>Ready to Join the St. Paul Family?</h2>
      <p>Give your child the gift of quality education in a nurturing, disciplined, and academically excellent environment. Admissions are now open for S.1, S.5, and boarding spaces.</p>
      <div class="cta-buttons">
        <a href="contact.php" class="btn btn-red">Apply Now &#8594;</a>
        <a href="about.php" class="btn btn-outline">Learn More</a>
      </div>
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
