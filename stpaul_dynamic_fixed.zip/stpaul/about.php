<?php require 'config.php';
$team=db()->query('SELECT * FROM team ORDER BY sort_order,id')->fetchAll();
$page='about'; $title='About Us | St. Paul Senior Secondary School'; $desc='About St. Paul Senior Secondary School — Our history, vision, mission, values, and team.';
require 'includes/header.php'; ?>

<!-- PAGE HERO -->
<section class="page-hero">
  <div class="container page-hero-content">
    <h1>About St. Paul School</h1>
    <div class="breadcrumb">
      <a href="index.php">Home</a>
      <span>&#8250;</span>
      <span>About Us</span>
    </div>
  </div>
</section>

<!-- SCHOOL BACKGROUND -->
<section class="intro-section section-padding">
  <div class="container">
    <div class="intro-grid">
      <div class="intro-image-wrap">
        <img src="images/campus/lab1.jpg" alt="St. Paul School Campus" />
        <div class="intro-badge">
          <span class="intro-badge-num">2006</span>
          <span class="intro-badge-label">Year Founded</span>
        </div>
      </div>
      <div class="intro-content">
        <span class="section-tag">Our History</span>
        <h2 class="section-title">A School Built on <span>Faith &amp; Excellence</span></h2>
        <p>St. Paul Senior Secondary School was established in 2006 at Rwengoma Hill, Bundibugyo Road, Fort Portal City in the Tooro region of Western Uganda. Founded on principles of Christian values, academic excellence, and community service, the school has grown steadily over two decades to become one of the leading secondary schools in the Fort Portal area.</p>
        <p>The school offers both the Ordinary Level (S.1–S.4) and Advanced Level (S.5–S.6) programs, providing a comprehensive and rigorous curriculum aligned with Uganda National Examinations Board (UNEB) standards. With a crest featuring an eagle, a cross, and an open book, St. Paul symbolizes freedom, faith, and knowledge — the three pillars of our educational philosophy.</p>
        <p>Today, St. Paul serves over 478 students, employs 64 dedicated staff, and has produced over 5,897 alumni who have gone on to universities, professions, and public service across Uganda and beyond.</p>
        <div class="intro-features">
          <div class="intro-feature">
            <div class="intro-feature-icon">&#127981;</div>
            <span>Government-registered with UNEB</span>
          </div>
          <div class="intro-feature">
            <div class="intro-feature-icon">&#127775;</div>
            <span>Consistently high UCE and UACE results</span>
          </div>
          <div class="intro-feature">
            <div class="intro-feature-icon">&#128100;</div>
            <span>5,897+ proud alumni across all sectors</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- VISION & MISSION -->
<section class="vision-mission section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Purpose &amp; Direction</span>
      <h2 class="section-title">Our Vision &amp; <span>Mission</span></h2>
      <div class="divider"></div>
    </div>
    <div class="vm-grid">
      <div class="vm-card">
        <div class="vm-card-accent"></div>
        <div class="vm-icon">&#128065;</div>
        <h3>Our Vision</h3>
        <p>To be a distict learning center,producing feature citizens who have a clear understanding of times,knowing what to do.</p>
      </div>
      <div class="vm-card mission">
        <div class="vm-card-accent"></div>
        <div class="vm-icon">&#127919;</div>
        <h3>Our Mission</h3>
        <p>To provide modern all round quality education through hardwork and integrity.</p>
      </div>
    </div>
  </div>
</section>

<!-- CORE VALUES -->
<section class="values-section section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">What We Stand For</span>
      <h2 class="section-title">Our Core <span>Values</span></h2>
      <div class="divider"></div>
      <p class="section-desc">These values guide every decision, interaction, and program at St. Paul Senior Secondary School.</p>
    </div>
    <div class="values-grid">
      <div class="value-card">
        <div class="value-icon">&#11088;</div>
        <h4>Excellence</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#9989;</div>
        <h4>Integrity</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#9878;&#65039;</div>
        <h4>Discipline</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#128161;</div>
        <h4>Innovation</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#129309;</div>
        <h4>Respect</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#128170;</div>
        <h4>Hard Work</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#9878;</div>
        <h4>Accountability</h4>
      </div>
      <div class="value-card">
        <div class="value-icon">&#127919;</div>
        <h4>Commitment</h4>
      </div>
    </div>
  </div>
</section>

<!-- HEADTEACHER MESSAGE -->
<section class="headteacher-section section-padding">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Leadership</span>
      <h2 class="section-title">Message from the <span>Headteacher</span></h2>
      <div class="divider"></div>
    </div>
    <div class="headteacher-grid">
      <div class="headteacher-img-wrap">
        <img src="images/team/headteacher.jpg" alt="Headteacher Busobozi Solomon" />
        <div class="headteacher-badge">
          <strong>Busobozi Solomon</strong>
          <span>Headteacher</span>
        </div>
      </div>
      <div class="headteacher-msg">
        <h3>Dear Students, Parents &amp; Visitors,</h3>
        <p class="msg-role">Headteacher — St. Paul Senior Secondary School</p>
        <p>Welcome to St. Paul Senior Secondary School, a place where we nurture not just academic brilliance but also the character, values, and vision that define great human beings. It is my honour to lead this incredible institution in our mission to invest in the future through education.</p>
        <p>At St. Paul, we believe that every child has unique potential waiting to be unlocked. Our team of dedicated teachers, counselors, and support staff work tirelessly to create a safe, stimulating, and spiritually grounded environment where students can thrive academically, socially, and personally.</p>
        <p>We are committed to providing a curriculum that is not only aligned with national standards but also responsive to the real-world challenges our students will face. Through classroom excellence, co-curricular activities, sports, and community engagements, we prepare our students to be confident, compassionate, and capable leaders.</p>
        <p>To our parents and guardians: thank you for entrusting us with your children. We partner with you as the primary educators in your child's life. Together, we are indeed investing for a better future.</p>
        <p>To all students: dream big, work hard, stay disciplined, and remember — your future is your responsibility, and we are here to walk with you every step of the way.</p>
        <p class="signature">— Busobozi Solomon, Headteacher</p>
      </div>
    </div>
  </div>
</section>

<!-- TEAM SECTION -->
<section class="team-section section-padding" style="background: var(--off-white);">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Our People</span>
      <h2 class="section-title">Meet Our <span>Leadership Team</span></h2>
      <div class="divider"></div>
      <p class="section-desc">Dedicated professionals committed to delivering quality education and school administration.</p>
    </div>
    <div class="team-grid">
<?php foreach($team as $m): ?>
<div class="team-card"><div class="team-img-wrap"><img src="<?= e($m['image']) ?>" alt="<?= e($m['name']) ?>" style="object-position: top;" /><div class="team-overlay"><a href="#" class="team-social">f</a></div></div>
<div class="team-info"><h4><?= e($m['name']) ?></h4><p class="role"><?= e($m['role']) ?></p><p><?= e($m['bio']) ?></p></div></div>
<?php endforeach; ?>
</div>
  </div>
</section>

<!-- CTA SECTION -->
<section class="cta-section">
  <div class="container">
    <div class="cta-box">
      <h2>Be Part of the St. Paul Community</h2>
      <p>Whether you are a prospective student, parent, or partner — we welcome you to join our growing family of learners, achievers, and leaders.</p>
      <div class="cta-buttons">
        <a href="contact.php" class="btn btn-red">Contact Admissions &#8594;</a>
        <a href="services.php" class="btn btn-outline">View Our Programs</a>
      </div>
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
