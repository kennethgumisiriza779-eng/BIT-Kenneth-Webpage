<?php
// ---- EDIT for local (XAMPP) and again for the live cPanel server ----
const DB_HOST='localhost', DB_NAME='stpaul', DB_USER='root', DB_PASS='';
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]);
session_start();
function db(){ static $p; if(!$p) $p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); return $p; }
function e($s){ return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8'); }
function csrf(){ $_SESSION['t']??=bin2hex(random_bytes(16)); return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">'; }
function check(){ if($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['t']??'',$_POST['t']??'')) die('Invalid request'); }
