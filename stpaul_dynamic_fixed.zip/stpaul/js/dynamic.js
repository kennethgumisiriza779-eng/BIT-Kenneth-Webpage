(function () {
  'use strict';
  var f = document.getElementById('contactForm');
  if (!f) return;
  // Runs before js/script.js, validates, then saves the message to MySQL through contact.php.
  window.addEventListener('submit', function (e) {
    if (e.target !== f) return;
    e.preventDefault(); e.stopPropagation();
    var ok = true;
    [['fullName','nameError',function(v){return v.trim()!=='';}],
     ['email','emailError',function(v){return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);}],
     ['subject','subjectError',function(v){return v!=='';}],
     ['message','messageError',function(v){return v.trim().length>=5;}]].forEach(function (r) {
      var good = r[2](f.elements[r[0]].value);
      document.getElementById(r[1]).style.display = good ? 'none' : 'block';
      if (!good) ok = false;
    });
    if (!ok) return;
    fetch('contact.php', { method: 'POST', body: new FormData(f), headers: { 'X-Requested-With': 'fetch' } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d.ok) { f.style.display = 'none'; document.getElementById('formSuccess').style.display = 'block'; }
        else alert(d.error || 'Could not send your message. Please try again.');
      })
      .catch(function () { alert('Network error. Please try again.'); });
  }, true);
})();
