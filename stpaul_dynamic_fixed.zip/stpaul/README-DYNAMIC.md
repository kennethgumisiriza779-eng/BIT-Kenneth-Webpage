# St. Paul website: dynamic version (PHP + MySQL)
Put these files in your existing project folder (your `css/`, `js/script.js` and `images/` stay as they are). The `.html` pages are replaced by `.php` pages.
1. Import `db/database.sql` in phpMyAdmin (it already holds your 15 gallery photos, 3 news items and 4 team members).
2. Edit `config.php` (database name, user, password).
3. Open `/admin/setup.php`, create the first admin (not "admin"), then DELETE `admin/setup.php`.
4. Log in at `/admin/login.php`. Manage news, gallery (with image upload), team and enquiries.
Live (cPanel): create DB and user, import the SQL, upload files, update `config.php`, enable the HTTPS lines in `.htaccess`.
Dynamic parts: home news, news page, about team, gallery and filters, contact form saved to the database. JOINs: news and gallery with categories. All queries use PDO prepared statements.
