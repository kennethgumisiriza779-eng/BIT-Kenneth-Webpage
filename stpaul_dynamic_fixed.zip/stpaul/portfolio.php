<?php require 'config.php';
$page='portfolio'; $title='Portfolio | St. Paul Senior Secondary School'; $desc='Portfolio of achievements, events, and success stories from St. Paul Senior Secondary School.';
require 'includes/header.php'; ?>

<!-- PAGE HERO -->
<section class="page-hero">
  <div class="container page-hero-content">
    <h1>Our Portfolio &amp; Achievements</h1>
    <div class="breadcrumb">
      <a href="index.php">Home</a>
      <span>&#8250;</span>
      <span>Portfolio</span>
    </div>
  </div>
</section>

<!-- STATS BANNER -->
<section class="stats-section" style="padding: 56px 0;">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item">
        <span class="stat-number">478+</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Active Students</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">5,897+</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Alumni</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">20+</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Years Active</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">64</span>
        <div class="stat-divider"></div>
        <span class="stat-label">Staff Members</span>
      </div>
    </div>
  </div>
</section>

<!-- PORTFOLIO GRID -->
<section class="portfolio-section">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Our Work &amp; Events</span>
      <h2 class="section-title">School <span>Achievements &amp; Projects</span></h2>
      <div class="divider"></div>
      <p class="section-desc">A showcase of academic excellence, co-curricular achievements, campus development, and student success stories.</p>
    </div>
    <div class="portfolio-grid">

      <!-- Academic Achievements -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/students_balcony.webp" alt="UACE Results" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Academics</span>
              <h3>Outstanding UACE Results 2025</h3>
              <p>Multiple students scored 20+ points in the 2025 UACE examinations.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Science Fair -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/school lab.jpg" alt="Science Fair" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Science</span>
              <h3>Annual Science &amp; Innovation Fair 2026</h3>
              <p>Students showcased creative engineering and agricultural models.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Trade Show -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/entreprenuer.jpg" alt="Trade Show" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Entrepreneurship</span>
              <h3>Student Entrepreneurship Trade Show</h3>
              <p>Students displayed products and business models to parents and community.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Football -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/sports/championship.jpg" alt="Football Team" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Sports</span>
              <h3>Regional Football Championship</h3>
              <p>Our football team qualified for the Fort Portal regional inter-school tournament.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Students Group -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/group photo.jpg" alt="Opening Ceremony" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Campus Life</span>
              <h3>Opening Ceremony 2026</h3>
              <p>Grand school opening welcomed over 478 students for the new academic year.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Girls Uniform -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/uniform.jpg" alt="Students in Uniform" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Discipline</span>
              <h3>Uniform &amp; Discipline Day</h3>
              <p>Celebrating school pride, identity, and discipline through smart uniforms.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Laboratory -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/campus/lab1.jpg" alt="Science Lab" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Facilities</span>
              <h3>New Science Laboratory Block</h3>
              <p>Fully equipped laboratory block with physics, chemistry and biology labs.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Assembly -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/assembly.jpg" alt="School Assembly" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Events</span>
              <h3>Annual Prize-Giving &amp; Assembly</h3>
              <p>Students and teachers gather for ceremonies celebrating academic excellence.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Van / Transport -->
      <div class="portfolio-card">
        <div class="portfolio-img-wrap">
          <img src="images/gallery/school van.jpg" alt="School Van" />
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat">Infrastructure</span>
              <h3>School Transport Van</h3>
              <p>A dedicated transport vehicle for official school activities and trips.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- HIGHLIGHTS / TESTIMONIAL STRIP -->
<section class="highlights-section" style="padding: 80px 0;">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Success Stories</span>
      <h2 class="section-title">What Our <span>Community Says</span></h2>
      <div class="divider"></div>
    </div>
    <div class="highlights-grid">
      <div class="highlight-card">
        <div class="highlight-icon">&#127942;</div>
        <h3>Academic Excellence</h3>
        <p>"St. Paul gave me the discipline and academic foundation to secure a government scholarship to Makerere University. I am proud to be an alumnus." — Former S.6 Student, Class of 2022</p>
      </div>
      <div class="highlight-card">
        <div class="highlight-icon">&#129309;</div>
        <h3>Parental Trust</h3>
        <p>"The teachers here are genuinely committed to every child. My son's grades improved dramatically in his first term. The boarding facilities are also excellent." — Parent, Fort Portal</p>
      </div>
      <div class="highlight-card">
        <div class="highlight-icon">&#127823;</div>
        <h3>Holistic Development</h3>
        <p>"Beyond academics, St. Paul taught us leadership, sportsmanship, and respect. These values have shaped my entire career." — Alumni, Class of 2019</p>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <div class="cta-box">
      <h2>Be Part of Our Success Story</h2>
      <p>Join hundreds of students who have transformed their lives through quality education at St. Paul Senior Secondary School.</p>
      <div class="cta-buttons">
        <a href="contact.php" class="btn btn-red">Apply Now &#8594;</a>
        <a href="gallery.php" class="btn btn-outline">View Gallery</a>
      </div>
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
