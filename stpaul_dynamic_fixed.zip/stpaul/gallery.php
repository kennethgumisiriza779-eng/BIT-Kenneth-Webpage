<?php require 'config.php';
$cats=db()->query('SELECT DISTINCT c.slug,c.name FROM categories c JOIN gallery g ON g.category_id=c.id ORDER BY c.name')->fetchAll();
$items=db()->query('SELECT g.*,c.slug FROM gallery g LEFT JOIN categories c ON c.id=g.category_id ORDER BY g.sort_order,g.id')->fetchAll();
$page='gallery'; $title='Gallery | St. Paul Senior Secondary School'; $desc='Photo gallery of St. Paul Senior Secondary School — campus, students, events, sports, and more.';
require 'includes/header.php'; ?>

<!-- PAGE HERO -->
<section class="page-hero">
  <div class="container page-hero-content">
    <h1>School Gallery</h1>
    <div class="breadcrumb">
      <a href="index.php">Home</a>
      <span>&#8250;</span>
      <span>Gallery</span>
    </div>
  </div>
</section>

<!-- GALLERY SECTION — EXACTLY 15 IMAGES -->
<section class="gallery-section">
  <div class="container">
    <div class="section-header">
      <span class="section-tag">Our Moments</span>
      <h2 class="section-title">Life at <span>St. Paul School</span></h2>
      <div class="divider"></div>
      <p class="section-desc">A visual journey through our campus, academics, sports, events, and vibrant school community.</p>
    </div>

    <div class="gallery-filter">
      <button class="filter-btn active" data-filter="all">All</button>
      <?php foreach($cats as $c): ?><button class="filter-btn" data-filter="<?= e($c['slug']) ?>"><?= e($c['name']) ?></button><?php endforeach; ?>
    </div>
    <div class="gallery-grid">
<?php foreach($items as $i): ?>
      <div class="gallery-item<?= $i['layout']!=='normal'?' '.e($i['layout']):'' ?>" data-category="<?= e($i['slug']) ?>">
        <img src="<?= e($i['image']) ?>" alt="<?= e($i['caption']) ?>" loading="lazy" />
        <div class="gallery-overlay"><div class="gallery-zoom-icon">&#128269;</div><p class="gallery-caption"><?= e($i['caption']) ?></p></div>
      </div>
<?php endforeach; ?>
    </div>
    <p style="text-align:center; margin-top:24px; font-size:0.8rem; color:var(--text-light);">Showing <?= count($items) ?> photos &bull; Click any image to enlarge</p>
  </div>
</section>

<!-- LIGHTBOX -->
<div class="lightbox" id="lightbox">
  <div class="lightbox-inner">
    <button class="lightbox-close" id="lightboxClose">&#10005;</button>
    <button class="lightbox-nav lightbox-prev" id="lightboxPrev">&#8592;</button>
    <img src="" alt="Gallery Image" class="lightbox-img" id="lightboxImg" />
    <p class="lightbox-caption" id="lightboxCaption"></p>
    <button class="lightbox-nav lightbox-next" id="lightboxNext">&#8594;</button>
  </div>
</div>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <div class="cta-box">
      <h2>Want to See More? Visit Us in Person</h2>
      <p>Come visit St. Paul Senior Secondary School at Rwengoma Hill, Fort Portal City and experience our vibrant campus and community firsthand.</p>
      <div class="cta-buttons">
        <a href="contact.php" class="btn btn-red">Get Directions &#8594;</a>
        <a href="portfolio.php" class="btn btn-outline">View Portfolio</a>
      </div>
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
