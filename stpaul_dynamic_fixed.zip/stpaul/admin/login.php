<?php require __DIR__.'/../config.php'; check(); $err='';
if(db()->query('SELECT COUNT(*) FROM users')->fetchColumn()==0){ header('Location: setup.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(($_SESSION['fails']??0)>=5 && time()-($_SESSION['last']??0)<300) $err='Too many attempts. Wait 5 minutes.';
  else{ $s=db()->prepare('SELECT * FROM users WHERE username=?'); $s->execute([trim($_POST['username'])]); $u=$s->fetch();
    if($u && password_verify($_POST['password'],$u['password_hash'])){ session_regenerate_id(true); $_SESSION['uid']=$u['id']; $_SESSION['fails']=0; header('Location: index.php'); exit; }
    $_SESSION['fails']=($_SESSION['fails']??0)+1; $_SESSION['last']=time(); $err='Wrong username or password.'; } }
$title='Login'; require '_head.php'; ?>
<h1>Admin login</h1><?php if($err) echo '<p class="flash">'.e($err).'</p>'; ?>
<form method="post" class="f"><?= csrf() ?><label>Username<input name="username" required></label><label>Password<input type="password" name="password" required></label><button>Login</button></form>
<?php require '_foot.php'; ?>
