<?php require '_auth.php'; $db=db();
if($_SERVER['REQUEST_METHOD']==='POST'){ $db->prepare('DELETE FROM enquiries WHERE id=?')->execute([(int)$_POST['id']]); header('Location: enquiries.php'); exit; }
$list=$db->query('SELECT * FROM enquiries ORDER BY id DESC')->fetchAll(); $title='Enquiries'; require '_head.php'; ?>
<h1>Enquiries</h1><table><tr><th>From</th><th>Subject</th><th>Message</th><th>Date</th><th></th></tr>
<?php foreach($list as $q): ?><tr><td><?= e($q['full_name']) ?><br><small><?= e($q['email']) ?> <?= e($q['phone']) ?></small></td><td><?= e($q['subject']) ?></td><td><?= nl2br(e($q['message'])) ?></td><td><?= e(substr($q['created_at'],0,10)) ?></td>
<td><form method="post" class="in" onsubmit="return confirm('Delete?')"><?= csrf() ?><input type="hidden" name="id" value="<?= $q['id'] ?>"><button>Delete</button></form></td></tr><?php endforeach; ?></table>
<?php require '_foot.php'; ?>
