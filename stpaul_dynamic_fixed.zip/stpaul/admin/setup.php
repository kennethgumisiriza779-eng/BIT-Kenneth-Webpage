<?php require __DIR__.'/../config.php'; check(); // creates the FIRST admin only. DELETE this file afterwards.
if(db()->query('SELECT COUNT(*) FROM users')->fetchColumn()>0) die('Setup already done. Delete this file.');
if($_SERVER['REQUEST_METHOD']==='POST' && strlen($_POST['password'])>=10 && trim($_POST['username'])!==''){
  db()->prepare('INSERT INTO users(username,password_hash) VALUES(?,?)')->execute([trim($_POST['username']),password_hash($_POST['password'],PASSWORD_DEFAULT)]); header('Location: login.php'); exit; }
$title='Setup'; require '_head.php'; ?>
<h1>Create first admin</h1><p>Do not use "admin" as the username. Password: 10+ characters.</p>
<form method="post" class="f"><?= csrf() ?><label>Username<input name="username" required></label><label>Password<input type="password" name="password" minlength="10" required></label><button>Create</button></form>
<?php require '_foot.php'; ?>
