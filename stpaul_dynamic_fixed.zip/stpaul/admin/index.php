<?php require '_auth.php'; $title='Dashboard'; $c=fn($t)=>db()->query("SELECT COUNT(*) FROM $t")->fetchColumn(); require '_head.php'; ?>
<h1>Dashboard</h1><div class="cards"><div class="card"><h2><?= $c('news') ?></h2>News posts</div><div class="card"><h2><?= $c('gallery') ?></h2>Gallery photos</div><div class="card"><h2><?= $c('team') ?></h2>Team members</div><div class="card"><h2><?= $c('enquiries') ?></h2>Enquiries</div></div>
<?php require '_foot.php'; ?>
