<?php require __DIR__.'/../config.php'; if(empty($_SESSION['uid'])){ header('Location: login.php'); exit; } check();
