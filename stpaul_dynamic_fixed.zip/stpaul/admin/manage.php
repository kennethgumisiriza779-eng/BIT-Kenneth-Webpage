<?php require '_auth.php'; $db=db();
// One CRUD engine for news, gallery and team. Table and column names come from this whitelist only; every value is a prepared-statement parameter.
$E=['news'=>['News',['title'=>['Title','text'],'category_id'=>['Category','cat'],'event_date'=>['Date','date'],'excerpt'=>['Short excerpt','textarea'],'body'=>['Full article','textarea'],'image'=>['Image','image']],'t.event_date DESC'],
'gallery'=>['Gallery',['caption'=>['Caption','text'],'category_id'=>['Category','cat'],'layout'=>['Layout','layout'],'sort_order'=>['Order','number'],'image'=>['Image','image']],'t.sort_order,t.id'],
'team'=>['Team',['name'=>['Name','text'],'role'=>['Role','text'],'bio'=>['Bio','textarea'],'sort_order'=>['Order','number'],'image'=>['Image','image']],'t.sort_order,t.id']];
$t=$_GET['t']??'news'; if(!isset($E[$t])) $t='news'; [$label,$cols,$order]=$E[$t]; $hasCat=isset($cols['category_id']); $first=array_key_first($cols);
function upload($f){ if(empty($f['name'])||$f['error']!==0||$f['size']>3*1024*1024) return null;
  $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name'])]??null; if(!$ext) return null;
  $n='images/uploads/'.bin2hex(random_bytes(8)).'.'.$ext; return move_uploaded_file($f['tmp_name'],__DIR__.'/../'.$n)?$n:null; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=(int)$_POST['id'];
  if(($_POST['action']??'')==='delete') $db->prepare("DELETE FROM $t WHERE id=?")->execute([$id]);
  else{ $v=[];
    foreach($cols as $k=>[$l,$ty]){ $x=trim($_POST[$k]??'');
      if($ty==='cat') $x=(int)$x?:null; elseif($ty==='number') $x=(int)$x;
      elseif($ty==='layout') $x=in_array($x,['normal','wide','tall'],true)?$x:'normal';
      elseif($ty==='date') $x=strtotime($x)?date('Y-m-d',strtotime($x)):date('Y-m-d');
      elseif($ty==='image') $x=upload($_FILES[$k]??[])??trim($_POST['old_'.$k]??'');
      $v[$k]=$x; }
    if($v[$first]!==''){ $n=array_keys($v);
      if($id) $db->prepare("UPDATE $t SET ".implode('=?,',$n)."=? WHERE id=?")->execute([...array_values($v),$id]);
      else $db->prepare("INSERT INTO $t(".implode(',',$n).") VALUES(".implode(',',array_fill(0,count($n),'?')).")")->execute(array_values($v)); } }
  header("Location: manage.php?t=$t"); exit; }
$row=['id'=>0,'event_date'=>date('Y-m-d'),'layout'=>'normal','sort_order'=>0];
if(isset($_GET['edit'])){ $s=$db->prepare("SELECT * FROM $t WHERE id=?"); $s->execute([(int)$_GET['edit']]); $row=$s->fetch()?:$row; }
$cats=$db->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$list=$db->query("SELECT t.*".($hasCat?",c.name AS cat":"")." FROM $t t ".($hasCat?"LEFT JOIN categories c ON c.id=t.category_id ":"")."ORDER BY $order")->fetchAll();
$title=$label; require '_head.php'; ?>
<h1><?= e($label) ?></h1>
<form method="post" enctype="multipart/form-data" class="f"><?= csrf() ?><input type="hidden" name="id" value="<?= $row['id'] ?>">
<?php foreach($cols as $k=>[$l,$ty]): $val=$row[$k]??''; ?><label><?= e($l) ?>
<?php if($ty==='textarea'): ?><textarea name="<?= $k ?>" rows="4"><?= e($val) ?></textarea>
<?php elseif($ty==='cat'): ?><select name="<?= $k ?>"><option value="">-</option><?php foreach($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $c['id']==$val?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
<?php elseif($ty==='layout'): ?><select name="<?= $k ?>"><?php foreach(['normal','wide','tall'] as $o): ?><option <?= $o===$val?'selected':'' ?>><?= $o ?></option><?php endforeach; ?></select>
<?php elseif($ty==='image'): ?><?php if($val): ?><img src="../<?= e($val) ?>" height="60" alt=""><?php endif; ?><input type="hidden" name="old_<?= $k ?>" value="<?= e($val) ?>"><input type="file" name="<?= $k ?>" accept="image/jpeg,image/png,image/webp">
<?php else: ?><input type="<?= $ty==='date'?'date':($ty==='number'?'number':'text') ?>" name="<?= $k ?>" value="<?= e($val) ?>"><?php endif; ?></label>
<?php endforeach; ?><button><?= $row['id']?'Update':'Add' ?></button></form>
<table><tr><th>Item</th><?php if($hasCat) echo '<th>Category</th>'; ?><th></th></tr>
<?php foreach($list as $r): ?><tr><td><?= e($r[$first]) ?></td><?php if($hasCat) echo '<td>'.e($r['cat']).'</td>'; ?><td><a href="?t=<?= $t ?>&edit=<?= $r['id'] ?>">Edit</a>
<form method="post" class="in" onsubmit="return confirm('Delete?')"><?= csrf() ?><input type="hidden" name="id" value="<?= $r['id'] ?>"><button name="action" value="delete">Delete</button></form></td></tr><?php endforeach; ?></table>
<?php require '_foot.php'; ?>
